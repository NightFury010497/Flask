Write-Host "Hold on.... Project is being Dockerized... Wait for a while"
Write-Host "Your Project will be running in  http://127.0.0.1:5000/  (fast)  and   http://localhost:5000/  (slow)"
docker-compose down
docker-compose run --service-ports web
Write-Host "Execution Finished"