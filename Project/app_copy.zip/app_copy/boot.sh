#!/bin/sh

exec gunicorn -k eventlet -w 1 app:app --log-file=-