####Written By Athul Nandaswaroop

optimized output on : http://127.0.0.1:5000/

An executable powershell script "easyloader.ps1" already given in this folder . . .
if autoscript is not runnig , give this command once in powershell opened as administrator and select Yes to All
	
	Set-ExecutionPolicy RemoteSigned

Alternatively.....

####### for linux users
   
1.open terminal in project root folder

2.to make sure that no identical containers are running parallel, first run 

	docker-compose down

3.type...   docker-compose run --service-ports web

thats all........

####### for windows users

0.Make sure that Docker is running 
	(set at least 3GB RAM, 4GB swap and 2 cpu cores as resources for getting this project compilied fastly)

1.open Windows PowerShell

2.type...   cd path_to_project root_folder(find from file manager)

3.type docker-compose down

4.docker-compose build

5. use any of the following command from below, first one is better.
     
    docker-compose run --service-ports web

    docker-compose up

###### For permanent background running

    docker-compose up -d  (it will make the project to run in background permanently untill getting a down command)